from azure.storage.blob import BlockBlobService, PublicAccess
import os

import Constants as cons



def UploadFiles(ContainerName,file_name,path):
 try:
    #Uploading  the output file to Azure
    # Create the BlockBlockService in TAP that is used to call the Blob service for the storage account


    #UNCOMMENT WHILE DEPLOYING INTO PRODUCTION-START
    
    # FETCH STORAGE ACCOUNT NAME FROM TABLE STORAGE
   #  = retrieveValueFromTable.FetchValueFromTableStorage(cons.UploadStorageAccountName)

    # FETCH STORAGE ACCOUNT KEY FROM KEY VAULT
  # StorageAccountKeyWest = retrieveFromKeyVault.FetchValuefromKeyVault(cons.UploadStorageAccountKey)

    # Create the BlockBlockService in MANAGED for WH that is used to call the Blob service for the storage account
    print('Print Container Name '+ContainerName)
    block_blob_service_Managed = BlockBlobService(account_name='stgactssacountrydev',
                                                    account_key='xIj6FLXRWILNdZtBBNTtwDKi2iHVIIMgKrW5bIuvBxLy6KtvM35M6Hx1V6clMeKwarlIawX5OfI3gVj8k7FmgQ==')
    #print('Connected to Managed Storage Container')


    #UNCOMMENT WHILE DEPLOYING INTO PRODUCTION-START
    
    #block_blob_service_TAP = BlockBlobService(account_name=StorageAcountName, account_key='/pDJEY26660LBSSlB6Y2qd1/MJh7+vEpGeWM3kxCsHSsmaX2CpI6372Kyb6YDEFCUAiyZs1kHOyQt2I5AIml1w==') 

    print('Connected to TAP Storage Container')
    #block_blob_service_TAP.create_blob_from_path("input/IM1-SmartSearch/Processed/IM1-SmartSearch-Enhanced", file_name_withoutext+'_Enhanced.tif', os.path.join(root,filename))
    '''if("Splits" in path):
        block_blob_service_TAP.create_blob_from_path("processed/IM1-SmartSearch/Processed/IM1-SmartSearch-Splits-Enhanced", file_name_withoutext+'_Enhanced.png', os.path.join(outputDir,file_name_withoutext)+'_Enhanced.png')#
    #else :
        #block_blob_service_TAP.create_blob_from_path("processed/IM1-SmartSearch/Processed/IM1-SmartSearch-Enhanced", file_name_withoutext+'_Enhanced.png', os.path.join(outputDir,file_name_withoutext)+'_Enhanced.png')#
        #print('File ' +file_name_withoutext+'_Enhanced.png'+ ' is uploaded to blob')'''
    
    path=path.replace("/", "\\")
    #GET CURRENT WORKING DIRECTORY
    cwd=os.getcwd()
    fullpath="".join(path.rsplit(cwd))
    #fullpath= fullpath.rsplit('\\',2)[0]
    fullpath= fullpath.replace(file_name,'').strip("\\").replace("\\decimated",'')
    #container = block_blob_service_Managed.create_container(ContainerName)
    #if container:
        #print ('Container %s created' %(ContainerName))
    #else:
        #print ('Container %s exists' %(ContainerName))
    print('Completed Successfully')
    block_blob_service_Managed.create_blob_from_path(ContainerName+"/"+fullpath, file_name, path)


    
    

 except Exception as e:
    print('Error occurred in uploadFilesToAzure.py for :::.'+file_name, e)

