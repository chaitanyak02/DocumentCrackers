import os, uuid, sys
import PIL
# import CheckFileType as FileType
from azure.storage.blob import BlockBlobService, PublicAccess
import os.path
from os import path

from PIL import Image, TiffTags, ExifTags
from PIL.ExifTags import TAGS 
from PIL import PngImagePlugin
import ExtractmagesFromPDF as ImageExtract

import pathlib


def DownloadFiles(DiskPath):
    try:
   

                        

            # Create the BlockBlockService and Blob service for the storage account
            block_blob_service_Managed = BlockBlobService(account_name='welldatastg',
                                                            account_key='BN19h+Zlfw4GqDozASJEUsir4dAf0n7lrIOhU708uw6eBXnoiSw0JoWF51x/cAOlEzSVGrk4Yn4L9T0l88FyGw==')
            print('Connected to Managed Storage Container')

            #FileName=os.path.splitext(os.path.basename(Constants.Download_File_Path))[0]+os.path.splitext(os.path.basename(Constants.Download_File_Path))[1]
             
            #FileFullPathLocation=os.path.dirname(FileFullPath)
            ContainerName='welldata'
            ContainerLocation=ContainerName+'/'+FileFullPathLocation
            generator = blob_service.list_blobs(ContainerName, prefix=DiskPath)
            for blob in generator:
                print("\t Blob name: " + blob.name)
            #if (str(path.exists(FileFullPathLocation)) == False):
            #        print("\nDownloading blob to " + FileFullPathLocation)
            block_blob_service_Managed.get_blob_to_path(
                    ContainerLocation , blob.name,DiskPath+'/'+blob.name)
            print('Blob Download is Sucessful!!')
                # CHECK FILE TYPE
              
            ImageExtract.ImageExtraction(DiskPath+'/'+blob.name)
                 
                

    except Exception as e:
        print('Error occurred in DownloadFilesFromBlob:::.', e)

    finally:
        print('\nAzure Storage Blob sample - Completed.\n')





