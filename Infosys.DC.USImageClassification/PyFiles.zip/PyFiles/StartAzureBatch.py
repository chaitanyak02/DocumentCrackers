import ssl
ssl._create_default_https_context = ssl._create_unverified_context 
import os
import sys
#from azure.keyvault import KeyVaultClient, KeyVaultAuthentication
#from azure.common.credentials import ServicePrincipalCredentials
import json
import os, uuid, sys
import  AzureDownloadFile as down
from os import path
credentials = None
from azure.storage.blob import BlockBlobService, PublicAccess


'''This module  will download all keys from Keyvault and store in the JSON file  which is stored in the current working directory of the Batch VM'''
try:
        #Read the parameters from batch program 
        print ('Number of arguments:', len(sys.argv), ' arguments.')
        print ('Argument List:', str(sys.argv))
        print ('Current Working Directory' +os.getcwd())
        print('Args Loaded-START')
        
       
        
        print('Args Loaded-END')
   

        #Find Filename
        #file_name_withoutext=os.path.splitext(os.path.basename(Constants.Download_File_Path))[0]
        #Find FileExtension
        #file_ext=os.path.splitext(os.path.basename(Constants.Download_File_Path))[1]
        #print('FileName'+file_name_withoutext)
        #print('file_ext'+file_ext)
       

        #if( ".PDF" in Constants.FileExtension or ".pdf" in Constants.FileExtension or ".TIFF" in Constants.FileExtension or ".tiff" in Constants.FileExtension or ".TIF" in Constants.FileExtension or ".tif" in Constants.FileExtension ) :
        #        print('Before FileDownload')  
                #Download file
        down.DownloadFiles(sys.argv[1])

except Exception as e:
       print('Error occurred in StartAzureBatch.py:::.', e)
       


