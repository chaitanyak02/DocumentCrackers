import sys,os
import PyPDF2
from PIL import Image
import Constants 
import fitz
import io
from pdfminer.converter import TextConverter
from pdfminer.pdfinterp import PDFPageInterpreter
from pdfminer.pdfinterp import PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.pdfinterp import resolve1
from pdfminer.pdfparser import PDFParser
from pdfminer.pdfdocument import PDFDocument
from pathlib import Path
import UploadFile as uploadFile
import UnsupervisedImageClassification as classifcation


def ImageExtraction(filepath):
    try:
         FileLocation=os.path.dirname(filepath)+"/"+Path(filepath).stem
         os.makedirs(FileLocation,exist_ok=True)
         doc = fitz.open(filepath)
         for i in range(len(doc)):
            for img in doc.getPageImageList(i):
                xref = img[0]
                pix = fitz.Pixmap(doc, xref)
                imagepath=FileLocation+"/p%s-%s.jpg" % (i, xref)
                if pix.n < 5:       # this is GRAY or RGB
                    pix.writePNG(imagepath)
                else:               # CMYK: convert to RGB first
                    pix1 = fitz.Pixmap(fitz.csRGB, pix)
                    pix1.writePNG(imagepath)
                    pix1 = None
                pix = None
                uploadFile.UploadFiles('PDF-Images',"/p%s-%s.jpg" % (i, xref),imagepath)
                #FU.UploadFiles(Constants.Image_Container,os.path.basename(imagepath),imagepath)
         #input = PyPDF2.PdfFileReader(open(filepath, "rb"))
         #for pgcnt in range(input.getNumPages()):
             #page0 = input.getPage(pgcnt)

             #if '/XObject' in page0['/Resources']:
              #  xObject = page0['/Resources']['/XObject'].getObject()

               # for obj in xObject:
                #    if xObject[obj]['/Subtype'] == '/Image':
                 #       size = (xObject[obj]['/Width'], xObject[obj]['/Height'])
                  #      data = xObject[obj].getData()
                   #     if xObject[obj]['/ColorSpace'] == '/DeviceRGB':
                    #        mode = "RGB"
                     #   else:
                      #      mode = "P"
                
                        #if '/Filter' in xObject[obj]:
                         #   if xObject[obj]['/Filter'] == '/FlateDecode':
                          #      img = Image.frombytes(mode, size, data)
                           #     img.save(obj[1:] + ".png")
                            #elif xObject[obj]['/Filter'] == '/DCTDecode':
                             #   img = open(obj[1:] + ".jpg", "wb")
                              #  img.write(data)
                               # img.close()
                            #elif xObject[obj]['/Filter'] == '/JPXDecode':
                             #   img = open(obj[1:] + ".jp2", "wb")
                             #   img.write(data)
                             #   img.close()
                            #elif xObject[obj]['/Filter'] == '/CCITTFaxDecode':
                             #   img = open(obj[1:] + ".tiff", "wb")
                             #   img.write(data)
                             #   img.close()
                        #else:
                        #    img = Image.frombytes(mode, size, data)
                        #    img.save(obj[1:] + ".png")
             #else:
             #   print("No image found.")
         
         #BD.BoxDetection(FileLocation,Path(filepath).stem)
         classifcation.ClassifyImages(imagepath)

    except Exception as e:
       print('Error occurred in ImageExtraction:::.', e)
       traceback.print_exc()